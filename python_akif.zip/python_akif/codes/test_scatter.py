import pandas as pd
import matplotlib.pyplot as plt
import sys
#create dataframe from csv
df=pd.read_csv('scatterplot_data', sep='\t', header=None, names=['col1', 'col2'])



#plotting
plt.scatter(df['col1'],df['col2'],color='#dd12dd',label="scatter-label")

#specifying labels
plt.xlabel("Year")
plt.ylabel("tax on general insurance premium")


plt.legend()
plt.show()
