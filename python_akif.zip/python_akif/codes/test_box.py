import pandas as pd
import matplotlib.pyplot as plt
import sys
#create dataframe from csv
df=pd.read_csv('boxplot_data', sep='\t', header=None, names=['col1', 'col2', 'col3'])
plotMap=[]

#create a list of lists where each list will have a corresponding box plot
plotMap.append(df['col2'].dropna().tolist())
plotMap.append(df['col3'].dropna().tolist())

#plotting
plt.boxplot(plotMap)

#specifying labels
plt.xticks([1,2], ['2006-07','2007-08'])
plt.xlabel("Year")
plt.ylabel("Tax generated in crores by various departments")


plt.legend()
plt.show()
