import pandas as pd
import matplotlib.pyplot as plt
import sys


#reading data frame from a csv file
df=pd.read_csv("barplot_data", header=None, names=['col1', 'col2'], sep='\t')

#plot bar plot with xticks which is position of bars as first argument and height of bars as second argument
plt.bar(range(1,25) ,df['col2'],color='#ddbbaa',label="bar-label")

#specify labels on xticks
plt.xticks(range(1,25),df['col1'],  rotation='vertical')
plt.xlabel("District")
plt.ylabel("Population in millions in year 2011")

#enabling legend
plt.legend()
plt.show()
